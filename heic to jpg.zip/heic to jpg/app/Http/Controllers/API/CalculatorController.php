<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\ApiController;

class CalculatorController extends ApiController
{
    
}
